import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        int  Baraja_En_Juego[];
        Baraja_En_Juego = new int [140];
        int cara_carta = 0,  activacion_reversa = 0;
        //cara de las cartas
           Scanner leer = new Scanner.class (String[] args) {
            Scanner leer = new Scanner(System.in);
            int reversa = 0;
            int turno_jugador = 1;
            while (reversa == 0);{
                 if (turno_jugador ==7);{
                     turno_jugador =1;
                 }else{
                    System.out.println("");
                }
            }
        }

        int reversa = 0;
        int jugador_1[];
        jugador_1 = new int[8];
        int jugador_2[];
        jugador_2 = new int[8];
        int jugador_3[];
        jugador_3 = new int[8];
        int jugador_4[];
        jugador_4 = new int[8];
        int jugador_5[];
        jugador_5 = new int[8];
        int jugador_6[];
        jugador_6 = new int[8];
        int jugador_7[];
        jugador_7 = new int[8];

        for (int aux=1; aux <= 120 ; aux++ ) {
            Baraja_En_Juego[aux] = cara_carta;
            System.out.println("Arreglo en posicion: " + aux + "   Tiene un:" + Baraja_En_Juego[aux]);
             if (cara_carta == 9) {
                 cara_carta = 0;
            }else{
                 if(cara_carta !=9)
                 cara_carta++;
            }
        }
        //se termina de llenar el arreglo
        int a = 0;
        for(int k = 1 ; k <= 7 ; k++){
            a = (int)((Math.random()*120 + 1));
            if (Baraja_En_Juego [a] == 70){
                k--;
            }
              jugador_1 [k] = Baraja_En_Juego[a];
              Baraja_En_Juego[a] = 70;
            System.out.println("Carta:" + k +"::::" + jugador_1 [k]);
        }
        for( int aux=1; aux<=120; aux++)
            if (Baraja_En_Juego[aux] !=70) {
                System.out.println("Carta:" + aux + "::: la posicion de la carta es:" + Baraja_En_Juego[aux]);
            }else{
                System.out.println("Carta:" + aux + "::: Esta carta esta ocupada" );
            }
        		import java.util.* ;
        public class pruebas{
            public static void main(String[] args) {
                Scanner leer = new Scanner(System.in); // aqui declaramos nuestro scanner
                //int leer_dato = leer.nextInt();
                int reversa = 0;  // va a ser reversa desactivada y el 1 va a ser la reversa activada
                int turno_jugador = 1;    // 80 reversa


                while(reversa == 0){
                    if(turno_jugador == 7){
                        turno_jugador = 1;
                    }else{
                        System.out.println("Turno del jugador: " + turno_jugador);
                        int leer_dato = leer.nextInt();
                        if(leer_dato == 80){
                            System.out.println("METISTE UNA REVERSA");
                            turno_jugador = turno_jugador - 2;
                            reversa = 1;
                        }
                        if(leer_dato == 90){
                            System.out.println("METISTE UN BLOQUEO");
                            turno_jugador++;
                        }
                        turno_jugador++;
                    }

                    while(reversa == 1){
                        if(turno_jugador == 0){
                            turno_jugador = 7;
                        }else{
                            System.out.println("Turno del jugador: " + turno_jugador);
                            int leer_dato = leer.nextInt();

                            if(leer_dato == 80){
                                System.out.println("METISTE UNA REVERSA");
                                turno_jugador = turno_jugador + 2;
                                reversa = 0;
                            }
                            if(leer_dato == 90){
                                System.out.println("METISTE UN BLOQUEO");
                                turno_jugador--;
                            }
                            turno_jugador--;
                        }
                    }
                }
    }
}